import java.util.ArrayList;

public class Module {
    private String moduleName;
    private double qcaPoints;
    private ArrayList<ModuleResult> moduleResults;
    private static final double CREDIT_HOURS = 6.0; // Each module worth 6 credit hours

    public Module(String moduleName, double qcaPoints) {
        this.moduleName = moduleName;
        this.qcaPoints = qcaPoints;
        this.moduleResults = new ArrayList<>();
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public double getQcaPoints() {
        return qcaPoints;
    }

    public void setQcaPoints(double qcaPoints) {
        this.qcaPoints = qcaPoints;
    }

    public double getCreditHours() {
        return CREDIT_HOURS;
    }

    public void addModuleResult(String grade) {
        ModuleResult result = new ModuleResult(moduleName, grade);
        moduleResults.add(result);
    }

    public ArrayList<ModuleResult> getModuleResults() {
        return moduleResults;
    }

    class ModuleResult {
        private String moduleName;
        private String grade;

        public ModuleResult(String moduleName, String grade) {
            this.moduleName = moduleName;
            this.grade = grade;
        }

        public String getModuleName() {
            return moduleName;
        }

        public String getGrade() {
            return grade;
        }
    }
}
