import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentsResults {
    private int yearCompleted;
    private Map<String, List<String>> moduleGrades; // Storing grades as strings for readability

    private static final Map<String, Double> GRADE_QPV_MAP = createGradeQPVMap();
    private static final Map<String, Boolean> GRADE_CREDITS_AWARDED_MAP = createGradeCreditsAwardedMap();

    public StudentsResults(int yearCompleted) {
        this.yearCompleted = yearCompleted;
        this.moduleGrades = new HashMap<>();
    }

    public void addModuleGrade(String moduleName, String grade) {
        if (!moduleGrades.containsKey(moduleName)) {
            moduleGrades.put(moduleName, new ArrayList<>());
        }
        moduleGrades.get(moduleName).add(grade);
    }

    private double calculateGradeQPV(String grade) {
        return GRADE_QPV_MAP.getOrDefault(grade, 0.0);
    }

    private boolean checkCreditsAwarded(String grade) {
        return GRADE_CREDITS_AWARDED_MAP.getOrDefault(grade, false);
    }

    public double calculateModuleAverageGrade(String moduleName) {
        if (moduleGrades.containsKey(moduleName)) {
            List<String> grades = moduleGrades.get(moduleName);
            double sum = 0.0;
            for (String grade : grades) {
                sum += calculateGradeQPV(grade);
            }
            return sum / grades.size();
        }
        return 0; // Return 0 if module not found or no grades entered
    }

    public double calculateQCA() {
        double totalPoints = 0.0;
        double totalCreditHours = 0.0;
        final double CREDIT_HOURS = 6.0;

        for (String moduleName : moduleGrades.keySet()) {
            double grade = calculateModuleAverageGrade(moduleName);
            totalPoints += grade * CREDIT_HOURS;
            totalCreditHours += CREDIT_HOURS;
        }

        if (totalCreditHours == 0) {
            throw new ArithmeticException("Division by zero: no modules added.");
        }

        return totalPoints / totalCreditHours;
    }

    private static Map<String, Double> createGradeQPVMap() {
        Map<String, Double> gradeQPVMap = new HashMap<>();
        // Populate the map with grade descriptors and their corresponding QPV
        gradeQPVMap.put("A1", 4.00);
        gradeQPVMap.put("A2", 3.60);
        gradeQPVMap.put("B1", 3.20);
        gradeQPVMap.put("B2", 3.00);
        gradeQPVMap.put("B3", 2.80);
        gradeQPVMap.put("C1", 2.60);
        gradeQPVMap.put("C2", 2.40);
        gradeQPVMap.put("C3", 2.00);
        gradeQPVMap.put("D1", 1.60);
        gradeQPVMap.put("D2", 1.20);
        gradeQPVMap.put("F", 0.00);
        gradeQPVMap.put("NG", 0.00);
        // Add other grade descriptors and their QPV values
        // ...

        return gradeQPVMap;
    }

    private static Map<String, Boolean> createGradeCreditsAwardedMap() {
        Map<String, Boolean> gradeCreditsAwardedMap = new HashMap<>();
        // Populate the map with grade descriptors and whether credits are awarded
        gradeCreditsAwardedMap.put("A1", true);
        gradeCreditsAwardedMap.put("A2", true);
        gradeCreditsAwardedMap.put("B1", true);
        gradeCreditsAwardedMap.put("B2", true);
        gradeCreditsAwardedMap.put("B3", true);
        gradeCreditsAwardedMap.put("C1", true);
        gradeCreditsAwardedMap.put("C2", true);
        gradeCreditsAwardedMap.put("C3", true);
        gradeCreditsAwardedMap.put("D1", true);
        gradeCreditsAwardedMap.put("D2", true);
        gradeCreditsAwardedMap.put("F", false);
        gradeCreditsAwardedMap.put("NG", false);
        // Add other grade descriptors and their corresponding credits awarded values
        // ...

        return gradeCreditsAwardedMap;
    }
}
