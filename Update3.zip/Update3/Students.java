import java.util.ArrayList;

class Students {
    private String name;
    private String id;
    private Program program;
    private int yearOfStudy;
    private ArrayList<StudentsTranscripts> studentsTranscripts;
    public Students(String name, String id, Program currentCourse) {
        this.name = name;
        this.id = id;
        this.program = currentCourse;
    }

    public void addTranscript() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, program, yearOfStudy);
        studentsTranscripts.add(transcript);
    }

    public void displayTranscripts() {
        for (StudentsTranscripts transcript : studentsTranscripts) {
            System.out.println(transcript);
        }
    }

    public void addResult(String module, String grade) {
        for (int i = 0; i < program.getModules().size(); i++ ) {
            if (program.getModules().get(i).getModuleName().equals(module)) {
                program.getModules().get(i).addGrade(grade);
            }
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }

    public void setStudentsTranscripts(ArrayList<StudentsTranscripts> studentsTranscripts) {
        this.studentsTranscripts = studentsTranscripts;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Program getProgram() {
        return program;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public ArrayList<StudentsTranscripts> getStudentsTranscripts() {
        return studentsTranscripts;
    }
}