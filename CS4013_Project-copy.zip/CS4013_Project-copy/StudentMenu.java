import java.util.Scanner;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


/**
   A menu for the appointment calendar system.
*/
public class StudentMenu
{
   private Scanner in;
   private Departments mainDepartment = new Departments("Main");
   ArrayList<Program> programs = new ArrayList<Program>();
   private boolean student = false;
   private boolean access = false;
   /**
      Constructs an AppointmentMenu object.
   */
   public StudentMenu() throws Exception
   {
       in = new Scanner(System.in);
       ReadCSVExample1 read = new ReadCSVExample1();
       String fileStart = "C:/Users/adamm/OneDrive/Documents/College/Year 2/";
       ArrayList<String> faculties = read.main(fileStart + "CSV_Example.CSV");
       
       
       for(int i=0;i<faculties.size();i++)
       {
            Faculty arts = new Faculty(faculties.get(i));
            mainDepartment.addFaculty(arts);
        }
        
       ArrayList<String> programStrings = read.main(fileStart + "Programs.CSV");
       //"C:/Users/adamm/OneDrive/Documents/College/Year 2/CSV_Example.CSV"
       int count = 0;
       String name = "";
       
       for(int i=0;i< programStrings.size();i++)
       {
           if(count==0)
           {
               name = programStrings.get(i);
               
            }
            if(count==1)
           {
               

            }
            if(count==2)
           {
               String programType = programStrings.get(i);
               Program prog = new Program(name,programType);
               programs.add(prog);
               count = -1;
               
            }
           count++;
        }
       ArrayList<String> moduleStrings = read.main(fileStart + "Modules.CSV");
       
       for(int i=0;i< moduleStrings.size();i=i+2)
       {
            for(int j=0;j< programs.size();j++)
            {
                if(programs.get(j).getProgramName().equals(moduleStrings.get(i)))
                {  
                    programs.get(j).addModule(new Module(moduleStrings.get(i+1),moduleStrings.get(i+1),1.0));
                }
            }
        }
       
   }
   public void access() throws Exception
    {
      boolean run = true;
      
      while (run)
      { 
          System.out.println("Enter ID:    (Or QUIT)");
          String command = in.nextLine().toUpperCase();
          
          if(command.equals("STUDENT"))
          {
              System.out.println("Enter Password:");
              String nextCommand = in.nextLine();
              
              if (nextCommand.equals("PasswordStudent"))
              {  
                access = false;
                run = false;
              }
              else
              {
                  System.out.println("Invalid Password");
                  System.out.println();
              }
          }
          else if(command.equals("DEPARTMENT"))
          {
              System.out.println("Enter Password:");
              String nextCommand = in.nextLine();
              
              
              if (in.equals("PasswordDepartment"))
              {  
                access = false;
                student = false;
                run = false;
              }  
              else
              {
                  System.out.println("Invalid ID");
                  System.out.println();
              }
          }
          else if(command.equals("QUIT"))
          {
                access = false;
          }
          else
          {
              System.out.println("Invalid ID");
              System.out.println();
          }
      }
      
      run();
    
    
    }

   /**
      Run the Main StudentMenu.
   */
    public void run()
    {   
        
        access = true;
        
      while (access)
      {  
         if(!student)
         {
         }
         System.out.printf("Adding:%nAdd S)tudent, Add M)odule, Add P)rogram,  Add G)rade%nView:%n");
         System.out.printf("Show F)aculties, Show A)ll Program Transcripts , Show Select T)ranscript%nExit:%n");
         System.out.printf("Q)uit%n");
         String command = in.nextLine().toUpperCase();

         if (command.equals("S"))
         {  
            addStudent();
        }
         else if (command.equals("M"))
         { 
             addModule();
         }
         else if (command.equals("P"))
         { 
             addProgram();
         }
         
         else if (command.equals("F"))
         { 
            System.out.printf("Facultys: %n ");
            for(int i = 0;i<mainDepartment.getFaculty().size();i++ )
            {
                System.out.println(mainDepartment.getStringFaculties().get(i));
            }
        }
         else if (command.equals("Q"))
         { 
            access = false;
         }
         else
         {
            System.out.printf("%nInvalid Command.%n%n");
            }
         
      }
   }
    private void addStudent()
    {
        System.out.println("Select Faculty");
            
            
        Faculty a = getChoice(mainDepartment.getFaculty());
        System.out.println("In " + a.getFacultyName() + " ,enter Student Course:  (Or BACK)");
        String courseCommand = in.nextLine().toUpperCase();
        
        if(courseCommand.equals("BACK"))
        {
            return;
        }
        System.out.println(courseCommand);
        boolean found = false;
        Program next = null;
        for(int i = 0; i<programs.size();i++)
        {
            if(courseCommand.equals(programs.get(i).getProgramName().toUpperCase()))
            {
                next = programs.get(i);
                found = true;
                System.out.println("added");
                    
                System.out.println("Enter student details: (Format: name,id number,year");
                String studentCommand = in.nextLine();
                   
                String name = "";
                String id = "";
                int year = 0;
                int h = 0;
                for(int j = 0;j<studentCommand.length();j++)
                {
                        
                    if(h==0 && studentCommand.charAt(j) != (','))
                    {
                        name = name + studentCommand.charAt(j);
                    }
                    if(h==1 && studentCommand.charAt(j) != (','))
                    {
                        id = id + studentCommand.charAt(j);
                    }
                    if(h==2 && studentCommand.charAt(j) != (','))
                    {
                        year = (int) studentCommand.charAt(j);
                    }
                    if(studentCommand.charAt(j) == (','))
                    {
                        h++;
                    }
                }
                    
                Students newest = new Students(name,id,next);
                a.addStudent(newest);
            }
        }
        if(courseCommand.equals("BACK"))
        {
            return;
        }
        else if(!found)
        {
            System.out.println("Not valid course") ; 
            addStudent();
        }
    }
    private void addModule()
    {
        System.out.println("Select Program");
        
        Program prog = getProgramChoice();
        System.out.println("Enter Name: ");
        String commandLine = in.nextLine();
        Module m = new Module(commandLine, commandLine,1.0);
        prog.addModule(m);
    }
    private void addProgram()
    {
        System.out.println("Enter name:");
        String name = in.nextLine();
        System.out.println("Enter duration:");
        String year = in.nextLine();
        System.out.println("Enter type(PostGrad,Research, etc.):");
        String type = in.nextLine();

        System.out.println("Is this correct(Enter Yes or No):");
        System.out.println("Name: " + name);
        System.out.println("Year Duration: " + year);
        System.out.println("Type of course: " + type);
        
        String confirm = in.nextLine();
        if(confirm.toUpperCase().equals("NO"))
        {
            addProgram();
        }
        else if(confirm.toUpperCase().equals("YES"))
        {
            Program setProgram = new Program(name,type);
            programs.add(setProgram);
        }
        else
        {
            System.out.println("Invalid Confirmation");
            addProgram();
        }
    
    }
   private Faculty getChoice(ArrayList<Faculty> choices)
   {
      if (choices.size() == 0){
          System.out.println("no Faculties");
         return null; 
      }
      while (true)
      {
         char c = 'A';
         for (Faculty choice : choices)
         {
            System.out.println(c + ") " + choice.getFacultyName()); 
            c++;
         }
         String input = in.nextLine();
         int n = input.toUpperCase().charAt(0) - 'A';
         if (0 <= n && n < choices.size())
            return choices.get(n);
      }      
   }
   private Program getProgramChoice()
   {
      if (programs.size() == 0){
          System.out.println("No valid programs");
         return null; 
      }
      while (true)
      {
         char c = 'A';
         for (Program choice : programs)
         {
            System.out.println(c + ") " + choice.getProgramName()); 
            c++;
         }
         String input = in.nextLine();
         int n = input.toUpperCase().charAt(0) - 'A';
         if (0 <= n && n < programs.size())
            return programs.get(n);
      }      
   }
}



