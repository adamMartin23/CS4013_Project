import java.util.ArrayList;

class StudentsTranscripts {
    private static String studentName;
    private static String studentId;
    private static Program program;
    private static int yearOfStudy;

    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.program = currentCourse;
        this.yearOfStudy = yearOfStudy;
    }

    public static String convertToString() {
        String transcriptString = "";
        transcriptString = "The student name is: " + studentName + "%nThe student id is: " +
                studentId + "%nThe students course is: " + "%nThe student year of study is: " +
                yearOfStudy + " year" + "%nThe students modules and grades are: ";
        for (int i = 0; i < program.getModules().size(); i++ ) {
            transcriptString = transcriptString + program.getModules().get(i);
            transcriptString = transcriptString + "%n";
            for (int j = 0; j < program.getModules().size(); j++ ) {
                transcriptString = transcriptString + Module.getGrade(j);
                transcriptString = transcriptString + "%n";
            }
        }
        return transcriptString;
    }
    public void setName(String name) {
        this.studentName = name;
    }

    public void setId(String id) {
        this.studentId = id;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentId() {
        return studentId;
    }

    public Program getCurrentCourse() {
        return program;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }
}