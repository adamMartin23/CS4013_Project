import java.util.ArrayList;

class StudentsTranscripts {
    private String studentName;
    private String studentId;
    private Program currentCourse;
    private int yearOfStudy;
    private ArrayList<ModuleResult> moduleResults;

    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy, ArrayList<ModuleResult> moduleResults) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.currentCourse = currentCourse;
        this.yearOfStudy = yearOfStudy;
        this.moduleResults = new ArrayList<>(moduleResults);
    }

    @Override
    public String toString() {
        StringBuilder transcriptString = new StringBuilder();
        transcriptString.append("Transcript for ").append(studentName).append(" (ID: ").append(studentId).append(")\n");
        transcriptString.append("Current Course: ").append(currentCourse).append("\n");
        transcriptString.append("Year of Study: ").append(yearOfStudy).append("\n");
        transcriptString.append("Module Results:\n");

        for (ModuleResult result : moduleResults) {
            transcriptString.append(result.getModuleName()).append(": ").append(result.getGrade()).append("\n");
        }

        return transcriptString.toString();
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentId() {
        return studentId;
    }

    public Program getCurrentCourse() {
        return currentCourse;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public ArrayList<ModuleResult> getModuleResults() {
        return moduleResults;
    }
}