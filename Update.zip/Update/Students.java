import java.util.ArrayList;

class Students {
    private String name;
    private String id;
    private Program currentCourse;
    private int yearOfStudy;
    private ArrayList<ModuleResult> studentResults;
    private ArrayList<StudentsTranscripts> studentsTranscripts;

    public Students(String name, String id, Program currentCourse, int yearOfStudy) {
        this.name = name;
        this.id = id;
        this.currentCourse = currentCourse;
        this.yearOfStudy = yearOfStudy;
        this.studentResults = new ArrayList<>();
        this.studentsTranscripts = new ArrayList<>();
    }

    public void addModuleResult(String moduleName, int moduleCredit, String grade) {
        ModuleResult moduleResult = new ModuleResult(moduleName, moduleCredit, grade);
        studentResults.add(moduleResult);
    }

    public void addTranscript() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, currentCourse, yearOfStudy, studentResults);
        studentsTranscripts.add(transcript);
        // Clear the studentResults after adding to transcript
        studentResults.clear();
    }

    public void displayTranscripts() {
        for (StudentsTranscripts transcript : studentsTranscripts) {
            System.out.println(transcript);
        }
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Program getCurrentCourse() {
        return currentCourse;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public ArrayList<StudentsTranscripts> getStudentsTranscripts() {
        return studentsTranscripts;
    }

    public ArrayList<ModuleResult> getStudentResults() {
        return studentResults;
    }
}