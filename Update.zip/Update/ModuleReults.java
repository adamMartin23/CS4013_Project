class ModuleResult {
    private String moduleName;
    private int moduleCredit;
    private String grade;

    public ModuleResult(String moduleName, int moduleCredit, String grade) {
        this.moduleName = moduleName;
        this.moduleCredit = moduleCredit;
        this.grade = grade;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getGrade() {
        return grade;
    }

    // Getter and setter methods
}