import java.util.ArrayList;

public class Faculty {
    private String facultyName;
    private ArrayList<Student> students;

    public Faculty(String facultyName) {
        this.facultyName = facultyName;
        this.students = new ArrayList<>();
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void setStudentResults(String studentID, String moduleCode, int semester, int year, String grade) {
        // Find the student with the given ID
        Student student = findStudentByID(studentID);

        if (student != null) {
            // Find the module in which results are to be set
            Module module = findModuleByCode(moduleCode);

            if (module != null) {
                // Set the results for the specified semester and year
                student.setResults(module, semester, year, grade);
                System.out.println("Results set successfully.");
            } else {
                System.out.println("Module not found.");
            }
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentDetails(String studentID) {
        // Find the student with the given ID
        Student student = findStudentByID(studentID);

        if (student != null) {
            // Display student details
            System.out.println("Student ID: " + student.getStudentID());
            System.out.println("Name: " + student.getStudentName());
            // Add more details as needed
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentResults(String studentID) {
        // Find the student with the given ID
        Student student = findStudentByID(studentID);

        if (student != null) {
            // Display student results
            student.displayResults();
        } else {
            System.out.println("Student not found.");
        }
    }

    private Student findStudentByID(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                return student;
            }
        }
        return null; // Student not found
    }

    private Module findModuleByCode(String moduleCode) {
        // Implement logic to find a module by its code
        // You may need to iterate through the modules of each student in the faculty
        // or maintain a separate list of modules for the faculty
        // Return the module if found, otherwise return null
        return null;
    }
}
