import java.util.ArrayList;

/**
     The class that stores all the programs details.
     */
public class Program {
    private final String programName;
    private int yearsOfStudy;
    private final String programType;  // e.g., undergraduate, postgraduate, taught, or research
    private final ArrayList<Module> modules;
    /**
     The construcor method that sets all the programs details.
     */
    public Program(String programName, String programType) {
        this.programName = programName;
        this.programType = programType;
        this.modules = new ArrayList<>();
    }
    /**
     This is a getter method for program name.
     `*/
    public String getProgramName() {
        return programName;
    }
    /**
     This is a getter method for length of the program.
     `*/
    public int getYearsOfStudy() {
        return yearsOfStudy;
    }
    /**
     This is a getter method for program's type.
     `*/
    public String getProgramType() {
        return programType;
    }
    /**
     This method adds a method to the method list in this program.
     `*/
    public void addModule(Module module) {
        modules.add(module);
    }
    /**
     This is a getter method for program's modules.
     `*/
    public ArrayList<Module> getModules() {
        return modules;
    }
}