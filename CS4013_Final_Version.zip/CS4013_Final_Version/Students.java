import java.util.ArrayList;

/**
 The class that stores all the students details.
 */
class Students {
    private String name;
    private String id;
    private Program program;
    private int yearOfStudy;
    private StudentsTranscripts studentsTranscripts;
    
    /**
     The construcor method that sets all the student details.
     */
    public Students(String name, String id, Program currentCourse,int year) {
        this.name = name;
        this.id = id;
        this.program = currentCourse;
        yearOfStudy = year;
        this.studentsTranscripts = new StudentsTranscripts(name, id, program, yearOfStudy); 
    }
    /**
     This method updates the transcript, can be called before displaying the students transcript.
     `*/
    public void updateTranscript() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, program, yearOfStudy);
    }
    /**
     This method prints the transcript.
     `*/
    public void displayTranscripts() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, program, yearOfStudy);
    
        System.out.printf(studentsTranscripts.convertToString());
    }
    /**
     This method prints all this students grades, in the format(Module name %n grade).
     `*/
    public void showAllGrades()
    {
        for(Module mod : program.getModules())
        {
             System.out.println(mod.getModuleName());            
            System.out.println(mod.getGrade(id));
        }
    
    }
    /**
     This method adds to the students grades, using the module code and grade in that module.
     `*/
    public void addResult(String module, double grade) {
        for (Module mods : program.getModules()) {
            if (mods.getModuleCode().equals(module)) {
                mods.addAGrade(id,grade);
            }
        }
    }
    /**
     This is a setter method for student name.
     `*/

    public void setName(String name) {
        this.name = name;
    }
    /**
     This is a setter method for student id.
     `*/
    public void setId(String id) {
        this.id = id;
    }
    /**
     This is a setter method for student program.
     `*/
    public void setProgram(Program program) {
        this.program = program;
    }
    /**
     This is a setter method for student year of study.
     `*/
    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }

    /**
     This is a getter method for student name.
     `*/
    public String getName() {
        return name;
    }
    /**
     This is a getter method for student id.
     `*/
    public String getId() {
        return id;
    }
    /**
     This is a getter method for student program.
     `*/
    public Program getProgram() {
        return program;
    }
    /**
     This is a getter method for student year of study.
     `*/
    public int getYearOfStudy() {
        return yearOfStudy;
    }

}