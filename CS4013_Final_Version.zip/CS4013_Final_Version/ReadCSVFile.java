import java.io.*;  
import java.util.Scanner;  
import java.util.ArrayList;

/**
      The Read CSV Class called through SystemStart.
   */
public class ReadCSVFile
{  
    /**
      The method that will convert a CSV with 'fileName' into a String ArrayList.
   */
    public ArrayList<String> main(String fileName) throws Exception  
    {  
        
        //"C:/Users/adamm/OneDrive/Documents/College/Year 2/New_CSV_Example.CSV"
        Scanner sc = new Scanner(new File(fileName));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            values.add(sc.next());
        }   
        sc.close();  
        return values;
    }  
}  
