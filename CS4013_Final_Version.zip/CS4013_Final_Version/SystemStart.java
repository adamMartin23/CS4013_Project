
import java.util.Scanner;
import java.util.ArrayList;

/**
 The class that starts the whole system.
 */
public class SystemStart
{
   private final Scanner in;
   
   private SystemMenu menu;
   
   
   /**
      Constructs an SystemStart object using the file address for the CSVs,  Example: "C:/Users/user1/Documents/College/New_Project_CSVs/".
   */
   public SystemStart(String csvFileLocation) throws Exception
   {
       in = new Scanner(System.in);
       menu = new SystemMenu(csvFileLocation);
       ReadCSVFile read = new ReadCSVFile();
       String fileStart = csvFileLocation;
       // Example: "C:/Users/adamm/OneDrive/Documents/College/Year 2/New_Project_CSVs/"
       
       ArrayList<String> faculties = read.main(fileStart + "Faculties.CSV");
       for (String faculty : faculties) {
           menu.addFaculty(faculty);
       }
       ArrayList<String> programStrings = read.main(fileStart + "Programs.CSV");
       int count = 0;
       String name = "";
       for (String programString : programStrings) {
           if (count == 0) {
               name = programString;
           }
           if (count == 2) {
               menu.addProgram(name, programString);
               count = -1;
           }
           count++;
       }
       ArrayList<String> moduleStrings = read.main(fileStart + "Modules.CSV");
       menu.addModule(moduleStrings);
       ArrayList<String> studentStrings = read.main(fileStart + "Students.CSV");
       int studCount = 0;
       String studName = "";
       String studID = "";
       String f = "";
       String pro = "";
       for (String studentString : studentStrings) {
           if (count == 0) {
               studName = studentString;
           }
           if (count == 1) {
               studID = studentString;
           }
           if (count == 2) {
               f = studentString;
           }
           if (count == 3) {
               pro = studentString;
           }
           if (count == 4) {
               menu.setStudent(studName,studID,f, pro,Integer.parseInt(studentString)) ;
               count = -1;
           }
           count++;
       }
       ArrayList<String> gradeStrings = read.main(fileStart + "Grades.CSV");
       menu.addGrades(gradeStrings);
   }
   /**
      The method used if you wish to access the student menu as either a student or the main department.
   */
   public void access() throws Exception
    {
      boolean run = true;
      boolean student = false;
      boolean access = false;
      String studentID = "";
      while (run)
      { 
          System.out.println("Student or Department?    (Or QUIT)");
          String command = in.nextLine().toUpperCase();

          switch (command) {
              case "STUDENT" -> {
                  
                  System.out.println("Enter ID:");
                  
                  String nextCommand = in.nextLine();
                  studentID = nextCommand;
                  System.out.println("Enter Password:");
                  
                  nextCommand = in.nextLine();
                  if (nextCommand.equals("PasswordStudent")) {
                      access = true;
                      student = true;
                      run = false;
                  } else {
                      System.out.println("Invalid Password");
                      System.out.println();
                  }
              }
              case "DEPARTMENT" -> {
                  System.out.println("Enter Password:");
                  String nextCommand = in.nextLine();


                  if (nextCommand.equals("PasswordDepartment")) {
                      access = true;
                      
                      run = false;
                  } else {
                      System.out.println("Invalid ID");
                      System.out.println();
                  }
              }
              case "QUIT" -> run = false;
              default -> {
                  System.out.println("Invalid ID");
                  System.out.println();
              }
          }
      }
      
      menu.run(student ,access, studentID);
    
    
    }
}
