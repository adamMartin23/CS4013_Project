import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
     The class that stores all the modules details.
     */
public class Module {
    private String moduleName;
    private String moduleCode;
    private double qcaPoints;
    private  Map<String, Double> moduleGrades;
    private static final double CREDIT_HOURS = 6.0; // Each module worth 6 credit hours
    private static final Map<String, Double> GRADE_TO_QCA_MAP = createGradeToQCAMap();
    private static final Map<String, Double> GRADE_TO_STRINGGRADE_MAP = createGradeMap();
    
    /**
     The construcor method that sets all the modules details.
     */
    public Module(String moduleName, String moduleCode, double qcaPoints) {
        this.moduleName = moduleName;
        this.moduleCode = moduleCode;
        this.qcaPoints = qcaPoints;
        moduleGrades = new HashMap<>();
        
    }
    /**
     This is a getter method for name of the module.
     `*/
    public String getModuleName() {
        return moduleName;
    }
    /**
     This is a setter method for name of the module.
     `*/
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }
    /**
     This is a getter method for code of the module.
     `*/
    public String getModuleCode() {
        return moduleCode;
    }
    /**
     This is a setter method for code of the module.
     `*/
    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }
    /**
     This is a getter method for the Qca Points of the module.
     `*/
    public double getQcaPoints() {
        return qcaPoints;
    }
    /**
     This is a setter method for the Qca Points of the module.
     `*/
    public void setQcaPoints(double qcaPoints) {
        this.qcaPoints = qcaPoints;
    }
    /**
     This is a getter method for the CreditHours of the module.
     `*/
    public double getCreditHours() {
        return CREDIT_HOURS;
    }
    /**
     This method adds a grade for the set student id or replaces it if there is already a grade for that student present.
     `*/
    public void addAGrade(String id, double grade) {
            if(moduleGrades.containsValue(id))
            {
                this.moduleGrades.replace(id,grade);
            }
            else
            {
                this.moduleGrades.put(id,grade);
            }
        
    }
    /**
     This is a getter method for grade of the selected student in the module.
     `*/
    public Double getGrade(String id)
    {
       return moduleGrades.get(id);
    }
    /**
     This is a getter method for all the grades of the module.
     `*/
    public Map<String, Double>  getGrades() {
        return moduleGrades;
    }
    /**
     This method calculates what the qca value is of the grade of a set student.
     `*/
    public double calculateModuleQCA(String Studentid) 
    {
        if (moduleGrades.get(Studentid) == null) 
        {
            return 0.0;
        }
        double sum = 0.0;
        sum += convertGradeToQCA(moduleGrades.get(Studentid));
        return sum;
    }

    private Double convertGradeToQCA(double grade) {

        String result = "";
        Double QCA = 0.0;
        for (String key: GRADE_TO_STRINGGRADE_MAP.keySet()) {
            if(GRADE_TO_STRINGGRADE_MAP.get(key) <= grade && (QCA < GRADE_TO_QCA_MAP.get(key)))
            {
                QCA = GRADE_TO_QCA_MAP.get(key);
            }
        }
        
        return QCA;
    }

    private static Map<String, Double> createGradeToQCAMap() {
        Map<String, Double> gradeToQCAMap = new HashMap<>();
        gradeToQCAMap.put("A1", 4.00);
        gradeToQCAMap.put("A2", 3.60);
        gradeToQCAMap.put("B1", 3.20);
        gradeToQCAMap.put("B2", 3.00);
        gradeToQCAMap.put("B3", 2.80);
        gradeToQCAMap.put("C1", 2.60);
        gradeToQCAMap.put("C2", 2.40);
        gradeToQCAMap.put("C3", 2.00);
        gradeToQCAMap.put("D1", 1.60);
        gradeToQCAMap.put("D2", 1.20);
        gradeToQCAMap.put("F", 0.00);
        gradeToQCAMap.put("NG", 0.00);
        return gradeToQCAMap;
    }
    private static Map<String, Double> createGradeMap() {
        Map<String, Double> gradeMap = new HashMap<>();
        gradeMap.put("A1", 80.0);
        gradeMap.put("A2", 72.0);
        gradeMap.put("B1", 64.0);
        gradeMap.put("B2", 60.0);
        gradeMap.put("B3", 56.0);
        gradeMap.put("C1", 52.0);
        gradeMap.put("C2", 48.0);
        gradeMap.put("C3", 40.0);
        gradeMap.put("D1", 35.0);
        gradeMap.put("D2", 30.0);
        gradeMap.put("F", 0.00);
        gradeMap.put("NG", 0.00);
        return gradeMap;
    }
}
