import java.util.ArrayList;


/**
 The class that calculates all the students results.
 */
class StudentsTranscripts{
    private String name;
    private String id;
    private Program program;
    private int yearOfStudy;
     
     /**
     The construcor method that sets all the transcripts' details.
     */
    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy) {
        this.name = studentName;
        this.id = studentId;
        program = currentCourse;
        this.yearOfStudy = yearOfStudy;
    }
    /**
     This method outputs a string which is the student transcript..
     */
    public String convertToString() {
        String transcriptString = "The student name is: " + name + "%nThe student id is: " +
                id + "%nThe students course is: " + program.getProgramName() + "%nThe student year of study is: " +
                yearOfStudy  + "%nThe students modules and grades are: %n";
        Double overallQCA = 0.0;
        for (int i = 0; i < program.getModules().size(); i++)
        {
            transcriptString = transcriptString + program.getModules().get(i).getModuleName();
            transcriptString = transcriptString + "%nGrade: ";
            transcriptString = transcriptString + program.getModules().get(i).getGrade(id);
            transcriptString = transcriptString + "%nAdded to QCA: ";
            transcriptString = transcriptString + program.getModules().get(i).calculateModuleQCA(id);
            transcriptString = transcriptString + "%n";
            overallQCA =  overallQCA + program.getModules().get(i).calculateModuleQCA(id);
        }
        overallQCA = overallQCA / (program.getModules().size()) ;
        transcriptString = transcriptString + "Your Current QCA is : " + overallQCA +  "%n";
        return transcriptString;
    }
    /**
     This is a getter method for name of the student who this transcript belongs.
     `*/
    public String getStudentName() {
        return name;
    }
    /**
     This is a getter method for id of the student who this transcript belongs.
     `*/
    public String getStudentId() {
        return id;
    }
    /**
     This is a getter method for course of the student who this transcript belongs.
     `*/
    public Program getCurrentCourse() {
        return program;
    }

}