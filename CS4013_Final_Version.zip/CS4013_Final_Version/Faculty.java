import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 The class that stores all the faculties' details(Name and Students in faculty).
 */
public class Faculty extends Departments{
    private final String facultyName;
    private final ArrayList<Students> students;
    
    /**
     The construcor method that sets all the faculties' details.
     */
    public Faculty(String facultyName, String departmentName) {
        super(departmentName);
        this.facultyName = facultyName;
        this.students = new ArrayList<>();
    }
    /**
     This is a getter method for name of the faculty.
     `*/
    public String getFacultyName() {
        return facultyName;
    }
    /**
     This is a getter method for students in this faculty.
     `*/
    public ArrayList<Students> getStudents() {
        return students;
    }
    /**
     This method adds a student to the student array in this faculty.
     `*/
    public void addStudent(Students student) {
        students.add(student);
    }
    /**
     This is a getter method for students results in this faculty.
     `*/
    public void getStudentResults(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student details
            System.out.println("Student ID: " + student.getId());
            System.out.println("Name: " + student.getName());
            System.out.println();
        } else {
            System.out.println("Student not found.");
        }
    }
     /**
     This method displays the transcripts of a selected student in this faculty.
     `*/
    public void displayStudentResults(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student results
            student.displayTranscripts();
        } else 
        {
            System.out.println("Student not found.");
        }
    }
     /**
     This is a getter method for a selected student in this faculty.
     `*/
    public Students findStudentByID(String studentID) {
        for (Students student : students) {
            if (student.getId().equals(studentID)) {
                return student;
            }
        }
        return null; // Student not found
    }
    
    private Module findModuleByCode(String moduleCode) {
        for (Students student : students) {
            // Iterate through the modules of each student
            for (Module module : student.getProgram().getModules()) {
                // Check if the module code matches the provided code
                if (module.getModuleCode().equals(moduleCode)) {
                    return module; // Return the module if found
                }
            }
        }
        return null; // Module not found
    }

}
