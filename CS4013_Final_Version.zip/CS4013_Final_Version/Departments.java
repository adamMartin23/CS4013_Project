import java.util.ArrayList;

/**
 The class that stores all the Departments details(Name and Faculties).
 */
public class Departments {
    private final String departmentName;
    private final ArrayList<Faculty> faculties;
    
    /**
     The construcor method that sets all the department details.
     */
    public Departments(String departmentName) {
        this.departmentName = departmentName;
        this.faculties = new ArrayList<>();
    }
    /**
     This is a getter method for the name of the faculties in this department.
     `*/
    public ArrayList<String> getStringFaculties() {
        ArrayList<String> end = new ArrayList<String>();
        for (Faculty faculty : faculties) {
            end.add(faculty.getFacultyName());
        }
        return end;
    }
    /**
     This is a getter method for department name.
     `*/
    public String getDepartmentName() {
        return departmentName;
    }
    /**
     This method adds a faculty to this department.
     `*/
    public void addFaculty(Faculty faculty) {
        faculties.add(faculty);
    }
    /**
     This is a getter method for the faculties in the department as an arraylist of faculties.
     `*/
    public ArrayList<Faculty> getFaculty() {
        return faculties;
    }
    
    /**
     This method displays the transcripts of all students in a set program.
     `*/
    public void viewProgress(String programName, int year) {
        System.out.println("Progress for " + programName + " in Year " + year + ":");

        for (Faculty faculty : faculties) {
            System.out.println("Faculty: " + faculty.getFacultyName());
            //GetStudents needs to be change
            ArrayList<Students> students = faculty.getStudents();

            for (Students student : students) {
                if (student.getProgram().getProgramName().equals(programName) && student.getProgram().getYearsOfStudy() == year) {
                    // Display student details or take other actions as needed
                    System.out.println("Student ID: " + student.getId());
                    System.out.println("Name: " + student.getName());
                    // Add more details as needed
                    System.out.println("Results:");
                    student.updateTranscript(); 
                    student.displayTranscripts();
                 }
            }
        }
    }
    
}
