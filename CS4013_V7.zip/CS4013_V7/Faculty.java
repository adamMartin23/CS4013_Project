import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Faculty 
{
    private final String facultyName;
    private final ArrayList<Students> students;
    //private final StudentsResults allResults = new StudentsResults(1);

    public Faculty(String facultyName) {
        this.facultyName = facultyName;
        this.students = new ArrayList<>();
    }

    public String getFacultyName() {
        return facultyName;
    }

    public ArrayList<Students> getStudents() {
        return students;
    }

    public void addStudent(Students student) {
        students.add(student);
    }

    /*public void setStudentResults(String studentID, String moduleCode, int semester, int year, double grade) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Find the module in which results are to be set
            Module module = findModuleByCode(moduleCode);

            if (module != null) {
                // Set the results for the specified semester and year
                module.setModuleName(moduleCode);
                student.setYearOfStudy(year);
                module.addGrade(grade);
                System.out.println("Results set successfully.");
            } else {
                System.out.println("Module not found.");
            }
        } else {
            System.out.println("Student not found.");
        }
    }
    */
    public void getStudentResults(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student details
            System.out.println("Student ID: " + student.getId());
            System.out.println("Name: " + student.getName());
            System.out.println();
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentResults(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student results
            student.displayTranscripts();
        } else 
        {
            System.out.println("Student not found.");
        }
    }

    public Students findStudentByID(String studentID) {
        for (Students student : students) {
            if (student.getId().equals(studentID)) {
                return student;
            }
        }
        return null; // Student not found
    }

    private Module findModuleByCode(String moduleCode) {
        for (Students student : students) {
            // Iterate through the modules of each student
            for (Module module : student.getProgram().getModules()) {
                // Check if the module code matches the provided code
                if (module.getModuleCode().equals(moduleCode)) {
                    return module; // Return the module if found
                }
            }
        }
        return null; // Module not found
    }

}
