import java.util.ArrayList;

class Students {
    private String name;
    private String id;
    private Program program;
    private int yearOfStudy;
    private StudentsTranscripts studentsTranscripts;
    public Students(String name, String id, Program currentCourse) {
        this.name = name;
        this.id = id;
        this.program = currentCourse;
        this.studentsTranscripts = new StudentsTranscripts(name, id, program, yearOfStudy); 
    }

    public void updateTranscript() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, program, yearOfStudy);
    }

    public void displayTranscripts() {
        StudentsTranscripts transcript = new StudentsTranscripts(name, id, program, yearOfStudy);
    
        System.out.printf(studentsTranscripts.convertToString());
    }
    public void showAllGrades()
    {
        for(Module mod : program.getModules())
        {
             System.out.println(mod.getModuleName());            
            System.out.println(mod.getGrade(id));
        }
    
    }
    
    public void addResult(String module, double grade) {
        for (Module mods : program.getModules()) {
            if (mods.getModuleCode().equals(module)) {
                mods.addAGrade(id,grade);
            }
        }
    }
    

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }


    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public Program getProgram() {
        return program;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

}