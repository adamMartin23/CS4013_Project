import java.util.ArrayList;

class StudentsTranscripts {
    private  String studentName;
    private  String studentId;
    private static Program program;
    private  int yearOfStudy;
    String transcriptString = "";

    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy) {
        this.studentName = studentName;
        this.studentId = studentId;
        program = currentCourse;
        this.yearOfStudy = yearOfStudy;
    }

    public String convertToString() {
        transcriptString = "The student name is: " + studentName + "%nThe student id is: " +
                studentId + "%nThe students course is: " + program.getProgramName() + "%nThe student year of study is: " +
                yearOfStudy  + "%nThe students modules and grades are: %n";
        for (int i = 0; i < program.getModules().size(); i++) {
            transcriptString = transcriptString + program.getModules().get(i).getModuleName();
            transcriptString = transcriptString + "%n";
            transcriptString = transcriptString + program.getModules().get(i).getGrade(studentId);
            transcriptString = transcriptString + "%n";
        }
        return transcriptString;
    }
    public void setName(String name) {
        this.studentName = name;
    }

    public void setId(String id) {
        this.studentId = id;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentId() {
        return studentId;
    }

    public Program getCurrentCourse() {
        return program;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }
}