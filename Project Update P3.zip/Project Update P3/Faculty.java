import java.util.ArrayList;

public class Faculty {
    private String facultyName;
    private ArrayList<Students> students;

    public Faculty(String facultyName) {
        this.facultyName = facultyName;
        this.students = new ArrayList<>();
    }

    public String getFacultyName() {
        return facultyName;
    }
    
    public ArrayList<Students> getStudents() {
        return students;
    }

    public void addStudent(Students student) {
        students.add(student);
    }

    public void setStudentResults(String studentID, String moduleCode, int semester, int year, String grade) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Find the module in which results are to be set
            Module module = findModuleByCode(moduleCode);

            if (module != null) {
                // Set the results for the specified semester and year
                module.setModuleName(moduleCode);
                student.setYearOfStudy(year);
                student.setGrade(grade);
                System.out.println("Results set successfully.");
            } else {
                System.out.println("Module not found.");
            }
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentDetails(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student details
            System.out.println("Student ID: " + student.getId());
            System.out.println("Name: " + student.getName());
            // Add more details as needed
        } else {
            System.out.println("Student not found.");
        }
    }

    public void displayStudentResults(String studentID) {
        // Find the student with the given ID
        Students student = findStudentByID(studentID);

        if (student != null) {
            // Display student results
            student.getStudentsResults();
        } else {
            System.out.println("Student not found.");
        }
    }

    private Students findStudentByID(String studentID) {
        for (Students student : students) {
            if (student.getId().equals(studentID)) {
                return student;
            }
        }
        return null; // Student not found
    }

    private Module findModuleByCode(String moduleCode) {
        for (Students student : students) {
                // Iterate through the modules of each student
                //Get modules needs to be changed to Muadhs spec
            for (Module module : student.getModules()) {
                // Check if the module code matches the provided code
                if (module.getModuleCode().equals(moduleCode)) {
                    return module; // Return the module if found
                }
            }
        }
        return null; // Module not found
    }

}
