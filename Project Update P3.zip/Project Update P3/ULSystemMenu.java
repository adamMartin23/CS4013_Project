public class ULSystemMenu
{
    public static void main()
    {
        
        //run whatever to test if the project works.
    
    }
}