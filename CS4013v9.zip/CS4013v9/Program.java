import java.util.ArrayList;

public class Program {
    private final String programName;
    private int yearsOfStudy;
    private final String programType;  // e.g., undergraduate, postgraduate, taught, or research
    private final ArrayList<Module> modules;

    public Program(String programName, String programType) {
        this.programName = programName;
        this.programType = programType;
        this.modules = new ArrayList<>();
    }

    public String getProgramName() {
        return programName;
    }

    public int getYearsOfStudy() {
        return yearsOfStudy;
    }

    public String getProgramType() {
        return programType;
    }

    public void addModule(Module module) {
        modules.add(module);
    }
    public ArrayList<Module> getModules() {
        return modules;
    }
}