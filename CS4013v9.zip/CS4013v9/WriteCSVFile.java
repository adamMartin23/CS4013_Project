import java.io.*;  
import java.util.Scanner;  
import java.util.ArrayList;

public class WriteCSVFile
{  
    
    private String csvLocation;
    
    public WriteCSVFile(String fileName)
    {
        csvLocation = fileName;
    }
    public void addFaculty(String faculityName,String departmentName) throws Exception
    {
        String line = "";
        String fileStart = csvLocation + "Faculties.CSV";
        Scanner sc = new Scanner(new File(fileStart));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            line = line + sc.next();
            line = line + ",";
        }   
    
        sc.close();
        File csvFile = new File(fileStart);
        FileWriter fileWriter = new FileWriter(csvFile);
        line = line + faculityName + "," + departmentName + ",";
        fileWriter.write(line.toString());
        fileWriter.close();
    }   
    public void addGrade(String moduleCode,String studentID, String grade) throws Exception
    {
        String line = "";
        String fileStart = csvLocation + "Grades.CSV";
        Scanner sc = new Scanner(new File(fileStart));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            line = line + sc.next();
            line = line + ",";
        }   
        sc.close();
        File csvFile = new File(fileStart);
        FileWriter fileWriter = new FileWriter(csvFile);
        line = line  + moduleCode + "," + studentID + "," + grade;
        fileWriter.write(line.toString());
        fileWriter.close();
    }   
    public void addModule(String courseName,String moduleName,String moduleCode) throws Exception
    {
        String line = "";
        String fileStart = csvLocation + "Modules.CSV";
        Scanner sc = new Scanner(new File(fileStart));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            line = line + sc.next();
            line = line + ",";
        }   
      
        sc.close();
        File csvFile = new File(fileStart);
        FileWriter fileWriter = new FileWriter(csvFile);
        line = line  + courseName + "," + moduleName + "," + moduleCode;
        fileWriter.write(line.toString());
        fileWriter.close();
    }   
    public void addProgram(String programName,String length,String type) throws Exception
    {
        String line = "";
        String fileStart = csvLocation + "Programs.CSV";
        Scanner sc = new Scanner(new File(fileStart));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            line = line + sc.next();
            line = line + ",";
        }   
     
        sc.close();
        File csvFile = new File(fileStart);
        FileWriter fileWriter = new FileWriter(csvFile);
        line = line  + programName + "," + length + "," + "type";
        fileWriter.write(line.toString());
        fileWriter.close();
    }  
    public void addStudent(String stuName,String stuID,String stuFaculty,String stuProgram,String stuYear) throws Exception
    {
        String line = "";
        String fileStart = csvLocation + "Students.CSV";
        Scanner sc = new Scanner(new File(fileStart));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            line = line + sc.next();
            line = line + ",";
        }   
        sc.close();
        File csvFile = new File(fileStart);
        FileWriter fileWriter = new FileWriter(csvFile);
        line = line + stuName + "," + stuID + "," + stuFaculty + "," + stuProgram + "," + stuYear;
        fileWriter.write(line.toString());
        fileWriter.close();
    }   
}  
