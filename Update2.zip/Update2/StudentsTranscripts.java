import java.util.ArrayList;

class StudentsTranscripts {
    private String studentName;
    private String studentId;
    private Program program;
    private int yearOfStudy;
    private ArrayList<ModuleResult> moduleResults;

    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy, ArrayList<ModuleResult> moduleResults) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.program = currentCourse;
        this.yearOfStudy = yearOfStudy;
        this.moduleResults = new ArrayList<>(moduleResults);
    }

    @Override
    public String toString() {
        StringBuilder transcriptString = new StringBuilder();
        transcriptString.append("Transcript for ").append(studentName).append(" (ID: ").append(studentId).append(")\n");
        transcriptString.append("Current Course: ").append(program).append("\n");
        transcriptString.append("Year of Study: ").append(yearOfStudy).append("\n");
        transcriptString.append("Module Results:\n");

        for (ModuleResult result : moduleResults) {
            transcriptString.append(result.getModuleName()).append(": ").append(result.getGrade()).append("\n");
        }

        return transcriptString.toString();
    }
    public void setName(String name) {
        this.studentName = name;
    }

    public void setId(String id) {
        this.studentId = id;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public void setYearOfStudy(int year) {
        this.yearOfStudy = year;
    }

    public void setModuleResults(ArrayList<ModuleResult> moduleResults) {
        this.moduleResults = moduleResults;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentId() {
        return studentId;
    }

    public Program getCurrentCourse() {
        return program;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public ArrayList<ModuleResult> getModuleResults() {
        return moduleResults;
    }
}