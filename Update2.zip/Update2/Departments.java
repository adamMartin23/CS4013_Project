import java.util.ArrayList;

public class Departments {
    private String departmentName;
    private ArrayList<Faculty> faculties;

    public Departments(String departmentName) {
        this.departmentName = departmentName;
        this.faculties = new ArrayList<>();
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void addFaculty(Faculty faculty) {
        faculties.add(faculty);
    }


    public void viewProgress(String programName, int year) {
        System.out.println("Progress for " + programName + " in Year " + year + ":");

        for (Faculty faculty : faculties) {
            System.out.println("Faculty: " + faculty.getFacultyName());
            ArrayList<Students> students = faculty.getStudents();

            for (Students student : students) {
                if (student.getProgram().getProgramName().equals(programName) && student.getProgram().getYearsOfStudy() == year) {
                    // Display student details or take other actions as needed
                    System.out.println("Student ID: " + student.getId());
                    System.out.println("Name: " + student.getName());
                    // Add more details as needed
                    System.out.println("Results:");
                    student.getStudentsResults();
                }
            }
        }
    }
}
