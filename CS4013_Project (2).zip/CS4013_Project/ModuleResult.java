public class ModuleResult {
    private String moduleName;
    private int moduleCredit;
    private String grade;

    public ModuleResult(String moduleName, int moduleCredit, String grade) 
    {
        this.moduleName = moduleName;
        this.moduleCredit = moduleCredit;
        this.grade = grade;
    }
    
    public char[] getModuleName() {
        return new char[0];
    }

    public char[] getGrade() {
        return new char[0];
    }

    // Getter and setter methods
}