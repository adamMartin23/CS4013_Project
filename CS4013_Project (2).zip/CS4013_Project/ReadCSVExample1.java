import java.io.*;  
import java.util.Scanner;  
import java.util.ArrayList;

public class ReadCSVExample1  
{  
    public ArrayList<String> main(String fileName) throws Exception  
    {  
        
        //"C:/Users/adamm/OneDrive/Documents/College/Year 2/CSV_Example.CSV"
        Scanner sc = new Scanner(new File(fileName));  
        sc.useDelimiter(",");   //sets the delimiter pattern  
        ArrayList<String> values = new ArrayList<String>();
        while (sc.hasNext())   
        {  
            values.add(sc.next());
            
            //System.out.println(sc.next());  //find and returns the next complete token from this scanner  
        }   
        sc.close();  
        return values;
    }  
}  
