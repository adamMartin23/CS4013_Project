import java.util.Scanner;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


/**
   A menu for the appointment calendar system.
*/
public class SystemMenu
{
   private final Scanner in;
   private final Departments mainDepartment;
   ArrayList<Program> programs = new ArrayList<Program>();
   private boolean student = false;
   private boolean access = false;
   private Students currentStudent;
   /**
      Constructs an AppointmentMenu object.
   */
   public SystemMenu() throws Exception
   {
       mainDepartment = new Departments("Main");
       in = new Scanner(System.in);
   }
   public void addProgram(String name, String type)
   {
        programs.add(new Program(name,type));
    }
    public void addFaculty(String name)
   {
       String departmentName = "Main";
       mainDepartment.addFaculty(new Faculty(name, departmentName));
    }
    public void setStudent(String name,String id,String faculty, String programName)
    {
        int year = 0;
        int h = 0;
        ArrayList<Faculty> fac = mainDepartment.getFaculty();
        for (int j = 0; j < programs.size(); j++) 
        {
             if(programs.get(j).getProgramName().equals(programName))
              {
                Students newest = new Students(name, id, programs.get(j));
                int i=0;
                for(Faculty f : fac)
                {
                    if(f.getFacultyName().equals(faculty))
                    {
                        f.addStudent(newest);
                    }
                }
             }
        }      
    }
    public void addModule(ArrayList<String> moduleStr)
   {
       ArrayList<String> moduleStrings = moduleStr;
       for(int i=0;i< moduleStrings.size();i=i+2)
       {
            for (Program program : programs)
            {
               if (program.getProgramName().equals(moduleStrings.get(i)))
               {
                   Module add = new Module(moduleStrings.get(i + 1), moduleStrings.get(i + 1), 1.0);
                   if(moduleStrings.get(i + 1).equals("CS4013"))
                   {
                       add.addAGrade("test",25);
                    }
                   program.addModule(new Module(moduleStrings.get(i + 1), moduleStrings.get(i + 1), 1.0));
                   
               }
           }
        }
    }
   /**
      Run the Main StudentMenu.
   */
    public void run(boolean isStudent,boolean access,String studentID)
    {   
        while (access)
      {
         if(isStudent)
         {
             System.out.printf("%nView:%n");
             System.out.printf("Show F)aculties, Show Your T)ranscripts , Show Your M)odules %nExit:%n");
             System.out.printf("Q)uit%n");
             String command = in.nextLine().toUpperCase();
             
             switch (command) {
                  case "M" -> viewModules(studentID);
                  case "F" ->  viewFaculties();
                  case "T" ->  viewTranscript(studentID);
                  case "Q" -> access = false;
                  default -> System.out.printf("%nInvalid Command.%n%n");
              }
         }
         else
         {
             System.out.printf("Add:%nAdd S)tudent, Add M)odule, Add P)rogram,  Add G)rade%nView:%n");
             System.out.printf("Show F)aculties, Show A)ll Program Transcripts , Show Select T)ranscript%nExit:%n");
             System.out.printf("Q)uit%n");
             String command = in.nextLine().toUpperCase();

              switch (command) {
                  case "S" -> addStudent();
                  case "M" -> addModule();
                  case "P" -> addProgram();
                  case "G" -> addGrade();
                  case "F" ->  viewFaculties();
                  case "C" ->  checkModuleGrades();
                  case "A" ->  viewAllTranscripts();
                  case "T" ->  viewSelectedTranscript();
                  case "Q" -> access = false;
                  default -> System.out.printf("%nInvalid Command.%n%n");
              }
         
         }
      }
   }
   private void viewModules(String id)
   {
      System.out.printf("Your Modules: %n");
      
      for(Faculty faculty : mainDepartment.getFaculty())
        {
            Students stu = faculty.findStudentByID(id);
            if(stu != null)
            {
                Program stuProgram = stu.getProgram();
                for (int i = 0; i < programs.size(); i++) 
              {
                  if(programs.get(i).equals(stuProgram))
                  {
                      for(Module mod : stuProgram.getModules())
                      {
                         System.out.println(mod.getModuleName());
                      }
                }
              }  
            }
        }
      
   }
   private void checkModuleGrades()
   {
     for(Program pro : programs)
     {
         for(Module mo : pro.getModules())
         {
                 System.out.println(mo.getModuleName());
                 for(int i=0;i<mo.getGrades().size();i++)
                 {
                     System.out.println(mo.getGrades().get("22371443"));
                }
         }
    
    }
    }
   private void viewTranscript(String studentID)
   {
        for(Faculty faculty : mainDepartment.getFaculty())
        {
            Students stu = faculty.findStudentByID(studentID);
            if(stu != null)
            {
                stu.displayTranscripts();
            }
        }
    }
   private void viewFaculties()
    {
           System.out.printf("Facultys: %n");
                  for (int i = 0; i < mainDepartment.getFaculty().size(); i++) {
                      System.out.println(mainDepartment.getStringFaculties().get(i));
                  }
       
    }
    private void addGrade()
    {
        System.out.println("Select Faculty");
            
            
        Faculty a = getChoice(mainDepartment.getFaculty());
        assert a != null;
        
        System.out.println("Enter Student ID:");
        String idCommand = in.nextLine();
        boolean found = false;
        
        for (Students testStudent : a.getStudents()) 
        {
            if(testStudent.getId().equals(idCommand))
            {   
                Program pro = testStudent.getProgram();
                found = true;
                
                if(pro.getModules().size()!= 0)
                {
                    
                    Module modul = getChoiceOfModule(pro.getModules());
                    System.out.println("Enter Grade:");
                    String gradeCommand = in.nextLine();
                    Double dub = Double.parseDouble(gradeCommand);
                    testStudent.addResult(modul.getModuleName(),Double.parseDouble(gradeCommand));
                }
                else
                {
                    System.out.println("This student has no modules");
                }
            }    
            if(!found)
            {
                System.out.println("Student not found.");
            }
        }
        
    }

    
    private void viewAllTranscripts()
    {
        System.out.println("Select Faculty");
            
            
        Faculty a = getChoice(mainDepartment.getFaculty());
        assert a != null;
        
        for (Students student : a.getStudents()) 
        {
            student.displayTranscripts();
        }
    }
    private void viewSelectedTranscript()
    {
        System.out.println("Select Faculty");
            
            
        Faculty a = getChoice(mainDepartment.getFaculty());
        assert a != null;
        System.out.println("Enter ID Number:");
        String idCommand = in.nextLine();
        boolean found = false;
        for (Students student : a.getStudents()) 
        {
            if(student.getId().equals(idCommand))
            {
                student.showAllGrades();
                student.displayTranscripts();
                found = true;
            }
        }
        if(!found)
        {
            System.out.println("Student not found.");
        }
    }
    private void addStudent()
    {
        System.out.println("Select Faculty");
            
            
        Faculty a = getChoice(mainDepartment.getFaculty());
        assert a != null;
        System.out.println("In " + a.getFacultyName() + " ,enter Student Course:  (Or BACK)");
        String courseCommand = in.nextLine().toUpperCase();
        
        if(courseCommand.equals("BACK"))
        {
            return;
        }
        System.out.println(courseCommand);
        boolean found = false;
        Program next = null;
        for (Program program : programs) {
            if (courseCommand.equals(program.getProgramName().toUpperCase())) {
                next = program;
                found = true;
                System.out.println("added");

                System.out.println("Enter student details: (Format: name,id number,year");
                String studentCommand = in.nextLine();

                String name = "";
                String id = "";
                int year = 0;
                int h = 0;
                for (int j = 0; j < studentCommand.length(); j++) {

                    if (h == 0 && studentCommand.charAt(j) != (',')) {
                        name = name + studentCommand.charAt(j);
                    }
                    if (h == 1 && studentCommand.charAt(j) != (',')) {
                        id = id + studentCommand.charAt(j);
                    }
                    if (h == 2 && studentCommand.charAt(j) != (',')) {
                        year = (int) studentCommand.charAt(j);
                    }
                    if (studentCommand.charAt(j) == (',')) {
                        h++;
                    }
                }

                Students newest = new Students(name, id, next);
                a.addStudent(newest);
            }
        }
        if(!found)
        {
            System.out.println("Not valid course") ; 
            addStudent();
        }
    }
    private void addModule()
    {
        System.out.println("Select Program");
        
        Program prog = getProgramChoice();
        System.out.println("Enter Name: ");
        String commandLine = in.nextLine();
        Module m = new Module(commandLine, commandLine,1.0);
        assert prog != null;
        prog.addModule(m);
    }
    private void addProgram()
    {
        System.out.println("Enter name:");
        String name = in.nextLine();
        System.out.println("Enter duration:");
        String year = in.nextLine();
        System.out.println("Enter type(PostGrad,Research, etc.):");
        String type = in.nextLine();

        System.out.println("Is this correct(Enter Yes or No):");
        System.out.println("Name: " + name);
        System.out.println("Year Duration: " + year);
        System.out.println("Type of course: " + type);
        
        String confirm = in.nextLine();
        if(confirm.equalsIgnoreCase("NO"))
        {
            addProgram();
        }
        else if(confirm.equalsIgnoreCase("YES"))
        {
            Program setProgram = new Program(name,type);
            programs.add(setProgram);
        }
        else
        {
            System.out.println("Invalid Confirmation");
            addProgram();
        }
    
    }
   private Faculty getChoice(ArrayList<Faculty> choices)
   {
      if (choices.size() == 0){
          System.out.println("no Faculties");
         return null; 
      }
      while (true)
      {
         char c = 'A';
         for (Faculty choice : choices)
         {
            System.out.println(c + ") " + choice.getFacultyName()); 
            c++;
         }
         String input = in.nextLine();
         int n = input.toUpperCase().charAt(0) - 'A';
         if (0 <= n && n < choices.size())
            return choices.get(n);
      }      
   }
   private Program getProgramChoice()
   {
      if (programs.size() == 0){
          System.out.println("No valid programs");
         return null; 
      }
      while (true)
      {
         char c = 'A';
         for (Program choice : programs)
         {
            System.out.println(c + ") " + choice.getProgramName()); 
            c++;
         }
         String input = in.nextLine();
         int n = input.toUpperCase().charAt(0) - 'A';
         if (0 <= n && n < programs.size())
            return programs.get(n);
      }      
   }
   
   private Module getChoiceOfModule(ArrayList<Module> modules)
   {
      if (modules.size() == 0){
          System.out.println("Program has no modules");
         return null; 
      }
      while (true)
      {
         char c = 'A';
         for (Module choice : modules)
         {
            System.out.println(c + ") " + choice.getModuleName()); 
            c++;
         }
         String input = in.nextLine();
         int n = input.toUpperCase().charAt(0) - 'A';
         if (0 <= n && n < modules.size())
            return modules.get(n);
      }      
   }
}    



