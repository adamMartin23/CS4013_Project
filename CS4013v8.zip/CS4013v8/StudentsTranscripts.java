import java.util.ArrayList;

class StudentsTranscripts extends Students{

    public StudentsTranscripts(String studentName, String studentId, Program currentCourse, int yearOfStudy) {
        super(studentName, studentId, currentCourse);
        this.name = studentName;
        this.id = studentId;
        program = currentCourse;
        this.yearOfStudy = yearOfStudy;
    }

    public String convertToString() {
        String transcriptString = "The student name is: " + name + "%nThe student id is: " +
                id + "%nThe students course is: " + program.getProgramName() + "%nThe student year of study is: " +
                yearOfStudy  + "%nThe students modules and grades are: %n";
        for (int i = 0; i < program.getModules().size(); i++) {
            transcriptString = transcriptString + program.getModules().get(i).getModuleName();
            transcriptString = transcriptString + "%n";
            transcriptString = transcriptString + program.getModules().get(i).getGrade(id);
            transcriptString = transcriptString + "%n";
        }
        return transcriptString;
    }

    public String getStudentName() {
        return name;
    }

    public String getStudentId() {
        return id;
    }

    public Program getCurrentCourse() {
        return program;
    }

}