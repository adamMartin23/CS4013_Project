
import java.util.Scanner;
import java.util.ArrayList;

public class SystemStart
{
   
   private final Scanner in;
   SystemMenu menu = new SystemMenu();
   /**
      Constructs an AppointmentMenu object.
   */
   public SystemStart() throws Exception
   {
       in = new Scanner(System.in);
       ReadCSVExample1 read = new ReadCSVExample1();
       String fileStart = "C:/Users/adamm/OneDrive/Documents/College/Year 2/Project_CSVs/";
       ArrayList<String> faculties = read.main(fileStart + "Faculties.CSV");
       for (String faculty : faculties) {
           menu.addFaculty(faculty);
       }
       ArrayList<String> programStrings = read.main(fileStart + "Programs.CSV");
       int count = 0;
       String name = "";
       for (String programString : programStrings) {
           if (count == 0) {
               name = programString;
           }
           if (count == 2) {
               menu.addProgram(name, programString);
               count = -1;
           }
           count++;
       }
       ArrayList<String> moduleStrings = read.main(fileStart + "Modules.CSV");
       menu.addModule(moduleStrings);
       ArrayList<String> studentStrings = read.main(fileStart + "Students.CSV");
       int studCount = 0;
       String studName = "";
       String studID = "";
       String f = "";
       
       for (String studentString : studentStrings) {
           if (count == 0) {
               studName = studentString;
           }
           if (count == 1) {
               studID = studentString;
           }
           if (count == 2) {
               f = studentString;
           }
           if (count == 3) {
               menu.setStudent(name,studID,f, studentString);
               count = -1;
           }
           count++;
           System.out.println("student");
       }
       
   }
   public void access() throws Exception
    {
      boolean run = true;
      boolean student = false;
      boolean access = false;
      String studentID = "";
      while (run)
      { 
          System.out.println("Student or Department?    (Or QUIT)");
          String command = in.nextLine().toUpperCase();

          switch (command) {
              case "STUDENT" -> {
                  
                  System.out.println("Enter ID:");
                  
                  String nextCommand = in.nextLine();

                  if (nextCommand.equals("PasswordStudent")) {
                      access = true;
                      student = false;
                      run = false;
                  } else {
                      System.out.println("Invalid Password");
                      System.out.println();
                  }
              }
              case "DEPARTMENT" -> {
                  System.out.println("Enter Password:");
                  String nextCommand = in.nextLine();


                  if (nextCommand.equals("PasswordDepartment")) {
                      access = true;
                      
                      run = false;
                  } else {
                      System.out.println("Invalid ID");
                      System.out.println();
                  }
              }
              case "QUIT" -> run = false;
              default -> {
                  System.out.println("Invalid ID");
                  System.out.println();
              }
          }
      }
      
      menu.run(student ,access, studentID);
    
    
    }
    public void start(){
    menu.run(false ,true, "1234");
}
}
