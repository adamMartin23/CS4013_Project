import java.util.ArrayList;

public class Departments {
    private final String departmentName;
    private final ArrayList<Faculty> faculties;
    private final StudentsResults allResults = new StudentsResults(1);


    public Departments(String departmentName) {
        this.departmentName = departmentName;
        this.faculties = new ArrayList<>();
    }
    
    public ArrayList<String> getStringFaculties() {
        ArrayList<String> end = new ArrayList<String>();
        for (Faculty faculty : faculties) {
            end.add(faculty.getFacultyName());
        }
        return end;
    }
    public String getDepartmentName() {
        return departmentName;
    }

    public void addFaculty(Faculty faculty) {
        faculties.add(faculty);
    }

    public ArrayList<Faculty> getFaculty() {
        return faculties;
    }

    public void viewProgress(String programName, int year) {
        System.out.println("Progress for " + programName + " in Year " + year + ":");

        for (Faculty faculty : faculties) {
            System.out.println("Faculty: " + faculty.getFacultyName());
            //GetStudents needs to be change
            ArrayList<Students> students = faculty.getStudents();

            for (Students student : students) {
                if (student.getProgram().getProgramName().equals(programName) && student.getProgram().getYearsOfStudy() == year) {
                    // Display student details or take other actions as needed
                    System.out.println("Student ID: " + student.getId());
                    System.out.println("Name: " + student.getName());
                    // Add more details as needed
                    System.out.println("Results:");
                    student.updateTranscript(); 
                    student.displayTranscripts();
                 }
            }
        }
    }
}
